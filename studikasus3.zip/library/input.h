using namespace std;

class Input {
	public :
		void cetak(){
			cout << "WARUNG MAKAN BAROKAHHH"<<endl;
			cout << "Menu yang tersedia : "<<endl;
			cout << "1) Ayam Geprek   Rp. 21000 \n";
      cout << "2) Ayam Goreng   Rp. 17000 \n";
			cout << "3) Udang Goreng  Rp. 19000 \n";
      cout << "4) Cumi Goreng   Rp. 20000 \n";
			cout << "5) Ayam Bakar    Rp. 25000 \n\n";
			cout << "Pesan Ayam Geprek  -> "; cin >> bnyk_aymGprk;
			cout << "Pesan Ayam Goreng  -> "; cin >> bnyk_aymGr;
      cout << "Pesan Udang Goreng -> "; cin >> bnyk_udgGr;
      cout << "Pesan Cumi Goreng  -> "; cin >> bnyk_cmGr;
      cout << "Pesan Ayam Bakar   -> "; cin >> bnyk_aymBk;
      
		}

		void toFile(){
			tulis_data.open("api_data.txt");
      tulis_data << bnyk_aymGprk << endl;
			tulis_data << bnyk_aymGr << endl;
      tulis_data << bnyk_udgGr << endl;
      tulis_data << bnyk_cmGr << endl;
			tulis_data << bnyk_aymBk;
			tulis_data.close();
		}

	private :
		ofstream tulis_data;
		int bnyk_aymGprk, bnyk_aymGr, bnyk_udgGr, bnyk_cmGr ,bnyk_aymBk;
};