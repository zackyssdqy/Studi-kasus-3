
using namespace std;

class Proses {
	public :
		void cetak(){
			cout << "Anda sebagai Proses \n";
		}

		void getData(){
			ambil_data.open("api_data.txt");
			bool ayam_geprek = true;
      bool ayam_goreng = true;
      bool udang_goreng = true;
      bool cumi_goreng = true;
      bool ayam_bakar = true;
      
			while(!ambil_data.eof()){
        if (ayam_geprek){
          ambil_data >> bnyk_aymGprk;
          ayam_geprek = false;
        }

				if (ayam_goreng){
					ambil_data >> bnyk_aymGr;
					ayam_goreng = false;
				}

        if (udang_goreng){
          ambil_data >> bnyk_udgGr;
          udang_goreng = false;
        }

        if (cumi_goreng){
          ambil_data >> bnyk_cmGr;
          cumi_goreng = false;
        }
          
			  if (ayam_bakar){
          ambil_data >> bnyk_aymBk;
          ayam_bakar = false;
        }
			}
			ambil_data.close();
		}

		void toFile(){
			int total = (hrg_aymGprk * bnyk_aymGprk) + (hrg_aymGr * bnyk_aymGr) + (hrg_udgGr * bnyk_udgGr) + (hrg_cmGr * bnyk_cmGr) + (hrg_aymBk * bnyk_aymBk);
			float batas = 45000;
			float t2 = float(total);
			float diskon = t2 * 0.1;

			if (total >= batas)
				t2 = t2 - diskon;


			tulis_data.open("api_data.txt");
			tulis_data << total << endl;
			tulis_data << diskon << endl;
			tulis_data << t2 << endl;
      tulis_data << bnyk_aymGprk << endl;
			tulis_data << bnyk_aymGr << endl;
      tulis_data << bnyk_udgGr << endl;
      tulis_data << bnyk_cmGr << endl;
			tulis_data << bnyk_aymBk;
			tulis_data.close();
		}

	private :
		ifstream ambil_data;
		ofstream tulis_data;
    int bnyk_aymGprk;
		int bnyk_aymGr;
    int bnyk_udgGr;
    int bnyk_cmGr;
		int bnyk_aymBk;

    int hrg_aymGprk = 21000;
		int hrg_aymGr = 17000;
    int hrg_udgGr = 19000;
    int hrg_cmGr = 20000; 
		int hrg_aymBk = 25000;
    
};